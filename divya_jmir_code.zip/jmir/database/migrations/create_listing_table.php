<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateListsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('listing', function(Blueprint $table)
		{
			$table->increments('id');
                        $table->string('name');
                        $table->string('telephone');
                        $table->string('postalcode');
                        $table->string('salary');
                        $table->string('province');
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('listing');
	}

}
