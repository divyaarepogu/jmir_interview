<?php 
namespace App;

use Illuminate\Database\Eloquent\Model;

class Lists extends Model {

	protected $table = 'listing';
        protected $fillable  = ['name','telephone','postalcode','salary','province'];
        
}
