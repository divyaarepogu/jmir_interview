<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Lists as Lists;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Session;

class ListController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index() {
        
        $listingList = Lists::paginate(10);
        
        //$listingList = Lists::all();
        $listingList->setPath('');
        return view('listing.index')->with('listingList', $listingList);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create() {
        return view('listing.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request) {
        // validation rules
        $this->validate($request,
                [
                'name' => 'required', 
                'telephone' => 'required|min:10', 
                'postalcode' => 'required|min:6',
                'salary' => 'required|min:5',
                'province' => 'required'
                ]); 
        
        Lists::create($request->all());
        

 
        \Session::flash('flash_message', 'Your data is saved, Go to listing page to see.');
        return redirect('listing');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id) {
        $list = Lists::find($id);
        return view('listing.show', compact('list'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id) {
        $list = Lists::findOrFail($id);
        return view('listing.edit',  compact('list'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request) {
         $this->validate($request,
                [
                'name' => 'required', 
                'telephone' => 'required|min:10', 
                'postalcode' => 'required|min:6',
                'salary' => 'required|min:5',
                'province' => 'required'
                ]);
        $list = Lists::findOrFail($id);
        $list->update($request->all());
        
        \Session::flash('flash_message', 'List has been Updated.');
        return redirect('listing');
    }
    
    public function delete($id) {
        Lists::find($id)->delete();
        die('ddd');
        \Session::flash('flash_message', 'List has been deleted.');
        return Redirect::route('listing');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id) {

        Lists::find($id)->delete();
        
        \Session::flash('flash_message', 'List has been deleted.');
        return Redirect::route('listing');
    }

public function confirmation(Request $request) {
        // validation rules
        $this->validate($request,
                [
                'name' => 'required', 
                'telephone' => 'required|min:10', 
                'postalcode' => 'required|min:6',
                'salary' => 'required|min:5',
                'province' => 'required'
                ]);
        
        Lists::create($request->all());
        
        \Session::flash('flash_message', 'Your data is saved, Go to listing page to see.');
        return redirect('listing');
    }



}
