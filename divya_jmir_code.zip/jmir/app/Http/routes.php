<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// set deafult route
Route::get('/', [
	'uses' => 'ListController@index', 
	'as' => 'home'
]);

/**
 * indivisual routing
 */
//Route::get('listing','ListController@index');
//Route::get('listing/create','ListController@create');
//Route::get('listing/{id}','ListController@show');
//Route::post('listing','ListController@store');
//Route::get('listing/{id}/edit','ListController@edit');
//Route::get('listing/{id}/delete', 'ListController@delete');
//Route::get('listing/{id}/destroy', 'ListController@destroy');


/**
 * this resource routing is for all indivisual routing
 */
Route::resource('listing','ListController');
Route::get('listing/{id}/delete', 'ListController@delete');