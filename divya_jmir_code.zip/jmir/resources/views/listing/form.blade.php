
<div class="form-group">
    {!! Form::label('name', 'NAME:') !!}
    {!! Form::text('name', null, ['class'=> 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::label('province', 'PROVINCE') !!}
    {!! Form::select('province', array('Ontario',
'Québec',
'Nova Scotia',
'New Brunswick',
'Manitoba',
'British Columbia',
'Prince Edward Island',
'Saskatchewan',
'Alberta',
'Newfoundland and Labrador',
'Northwest Territories',
'Yukon',
'Nunavut'), Input::old('province'), 
    array('class' => 'form-control')) !!}


</div>

<div class="form-group">
    {!! Form::label('telephone', 'TELEPHONE:') !!}
    {!! Form::text('telephone', null, ['class'=> 'form-control']) !!}
</div>


<div class="form-group">
    {!! Form::label('postalcode', 'POSTALCODE:') !!}
    {!! Form::text('postalcode', null, ['class'=> 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::label('salary', 'SALARY:') !!}
    {!! Form::text('salary', null, ['class'=> 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::submit($submitTextButton, array('class' => 'btn btn-primary')) !!}
</div>
