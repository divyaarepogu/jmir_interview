@extends('template')

@section('content')

<div class="panel panel-default">
    <div class="panel-heading">List</div>
    <div class="panel-body">
        <div class="row col-md-10">
            <div class="row">
                <div class="form-group">
                    <label class="col-sm-6"><div class="pull-right">&nbsp;</div></label>
                    <div class="col-sm-6"></div>
                </div>
            </div>
            
                <div class="row">
                    <div class="form-group">
                        <label class="col-sm-6">
                            <div class="pull-right">
                                NAME*: 
                            </div>
                        </label>
                        <div class="col-sm-6">{{ $list->name}}</div>
                    </div>
                </div>
				            <div class="row">
                    <div class="form-group">
                        <label class="col-sm-6">
                            <div class="pull-right">
                                PROVINCE: 
                            </div>
                        </label>
                        <div class="col-sm-6">{{ $list->province}}</div>
                    </div>
                </div>
            <div class="row">
                    <div class="form-group">
                        <label class="col-sm-6">
                            <div class="pull-right">
                                TELEPHONE*: 
                            </div>
                        </label>
                        <div class="col-sm-6">{{ $list->telephone}}</div>
                    </div>
                </div>
            <div class="row">
                    <div class="form-group">
                        <label class="col-sm-6">
                            <div class="pull-right">
                                POSTALCODE*: 
                            </div>
                        </label>
                        <div class="col-sm-6">{{ $list->postalcode}}</div>
                    </div>
                </div>
            <div class="row">
                    <div class="form-group">
                        <label class="col-sm-6">
                            <div class="pull-right">
                                SALARY: 
                            </div>
                        </label>
                        <div class="col-sm-6">{{ $list->salary}}</div>
                    </div>
                </div>

            
        </div>
    </div>
</div>

@stop