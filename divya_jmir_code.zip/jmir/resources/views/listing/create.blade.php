@extends('template')

@section('content')
<div class="col-md-2"></div>
<div class="col-md-8">

{!! Form::open(['url' => 'listing']) !!}
    <!-- include is used for render partial view errors/form_error.blade.php and listing/form.blade.php -->
    @include('errors.form_error')
    @include('listing.form', ['submitTextButton' => 'SAVE'])
  
 {!! Form::close() !!}
</div>
<div class="col-md-2"></div>
@stop