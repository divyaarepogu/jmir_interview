<div class="navbar">
    <div class="navbar-inner">
        <ul class="nav">
            <li><a href="/create">ADD INFORMATION </a></li>
            <li><a href="/listing">LISTING PAGE</a></li>
        </ul>
    </div>
</div>