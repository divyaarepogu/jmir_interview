@extends('template')
<div class="col-md-1"></div>
<div class="col-md-8">
<h1>Confirmaion Information</h1>

@section('content')
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>NAME</th>
                    <th>PROVINCE</th>
                    <th>TELEPHONE</th>
                    <th>POSTALCODE</th>
                    <th>SALARY</th>
                    <th colspan="3" align="center">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $i=0; ?>
                @foreach ($listingList as $list)
                    <?php $i++; ?>
                <tr>
                    <td>{{ $i }}</td>
                    <td>{{ $list->name }}</td>
                    <td>$list->province</td>
                    <td>{{ $list->telephone }}</td>
                    <td>{{ $list->postalcode }}</td>
                    <td>{{ $list->salary }}</td>
                    <td><a class="btn btn-warning" href="{{ url('/listing/'.$list->id.'/edit')}}">Update</a></td>
                    <td><a class="btn btn-danger" href="{{ action('ListController@destroy', $list->id) }}">Delete</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <center>
        {!!$listingList->render()!!}
     </center>

</div>
<div class="col-md-2"></div>
@stop