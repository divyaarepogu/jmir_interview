@extends('template')

@section('content')

<!--{!! Form::open(['method' => 'PATCH', 'url' => 'listing/' . $list->id]) !!}-->
{!! Form::model($list, ['method' => 'PATCH', 'action' => ['ListController@update', $list->id] ]) !!}

    @include('errors.form_error')
    @include('listing.form', ['submitTextButton' => 'Edit list'])
    
{!! Form::close() !!}

@stop