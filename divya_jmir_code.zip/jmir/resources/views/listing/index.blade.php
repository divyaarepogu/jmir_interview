@extends('template')
<div class="col-md-1"></div>
<div class="col-md-8">
@section('content')
<div class="col-md-2"></div>
<div class="col-md-10" style="top: 10px; float: middle; text-align: center;">
    @if ($listingList->count())
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>NAME</th>
                    <th>PROVINCE</th>
                    <th>TELEPHONE</th>
                    <th>POSTALCODE</th>
                    <th>SALARY</th>
                    <th align="center">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $i=0; ?>
                @foreach ($listingList as $list)
                    <?php $i++; ?>
                <tr>

                    <td>{{ $list->name }}</td>
		    <td>{{ $list->province }}</td>
                    <td>{{ $list->telephone }}</td>
                    <td>{{ $list->postalcode }}</td>
                    <td>{{ $list->salary }}</td>
                    
                    <td><a  href="{{ url('/listing/'.$list->id.'/edit')}}">Update</a> | <a  href="{{ action('ListController@destroy', $list->id) }}">Delete</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <center>
        {!!$listingList->render()!!}
     </center>
    @else
        There are no list in the list list
    @endif
</div>
<div class="col-md-2"></div>
@stop