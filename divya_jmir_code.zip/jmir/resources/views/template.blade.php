<!doctype html>
<html>
    <head>
        <telephone>JMIR - @yield('telephone')</telephone>
        <meta charset="utf-8">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <!-- Scripts -->

    </head>
    <body>
	<div class="col-md-2"></div>
<div class="col-md-8">
<div class="navbar" style="top: 10px; float: middle; text-align: center;">
    <div class="navbar-inner">
       
            <a href="{{ url('/listing/create')}}">ADD INFORMATION</a>  |   <a href="{{ url('/listing')}}">LISTING PAGE</a>

    </div>
</div>
</div>
<div class="col-md-2"></div>
        <div class="container">
            @if(Session::has('flash_message'))
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                 
                {{ Session::get('flash_message') }}
            </div>
            @endif
            <br>
            @yield('content')
        </div>

    </body>
</html>